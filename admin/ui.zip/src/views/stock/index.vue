<template>
<div>
  <router-view></router-view>
</div>
</template>

<script>
export default {
  name: "children"
}
</script>

<style scoped>

</style>
